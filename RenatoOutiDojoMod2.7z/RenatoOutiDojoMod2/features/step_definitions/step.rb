﻿Dado(/^que estou na pesquisa sobre Star Wars$/) do
  visit 'https://docs.google.com/forms/d/1tNSQzS6tAjh0PJtnewgKW8ddznAoGpX-2D-P7x0BXyY/viewform?edit_requested=true'
  @pesquisa = PesqStarWars.new
  @pesquisa.btnProx.click
end

Quando(/^respondo todas as perguntas$/) do
  @pesquisa.nome.set Faker::LordOfTheRings.character
  @pesquisa.mail.set 'star@trek.com'
  @pesquisa.radioGostaNao.click
  @pesquisa.filmeNenhum.click
  @pesquisa.persoFav.set Faker::Space.constellation
  @pesquisa.listProx.click
  @pesquisa.radioProxNao.click
end

Quando(/^envio as respostas$/) do
  @pesquisa.btnEnviar.click
end

Então(/^a pesquisa é respondidda com sucesso$/) do
 assert_text('Obrigado por responder as perguntas! =)')
end